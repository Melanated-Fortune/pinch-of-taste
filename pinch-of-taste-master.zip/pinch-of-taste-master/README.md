# pinch-of-taste
A mini project to showcase Html, Css and Java script. Using Bootstrap css framework.
